[!!IMPORTANT!!]
Insert this folder into this directory:
[INSTALLATION LOCATION]/Algodoo/scenes/phunlets

        _____
     .-'     '-.
   .'           '.
  /               \
 ;                 ;
 |                 |
 ;                 ;
  \               /
   '.           .'
     '-._____.-'

Thank you for downloading the MarbleSquared Pack! Your use of this pack will help revolutionise the Marble Race Community.

---

THINGS TO KNOW

 - Use converters for diagonal peices and back, and use the Diagonal Connector to keep the diagonal peices hole-less.
 - There will be a new track group coming soon.

---

CONTACT

If you made a peice or a group of peices with this pack, try sharing it to Rustox#0051, it may be included in future pack updates!

---

CHANGELOG

1.0 Beta
 + Diagonal Group
  + Connectors
   + Diagonal Connector
   + Diagonal Connector Cutter
  + Navigation
   + Diagonal Convertor
   + Diagonal Line
   + Diagonal Organizer
   + Diagonal Turn
 + Square Group
  + Building Kit
   + Cutter [Circle]
   + Cutter [Rectangle]
   + Part Base [Filled]
   + Part Base [Outline]
   + Wall Corner
   + Wall
  + Modules
   + Timed Jump
  + Navigation
   + Boosters
    + Booster [T]
    + Booster Line [L]
    + Booster Line [R]
    + Booster Turn [DL]
    + Booster Turn [DR]
    + Booster Turn [LU - RU]
    + Booster Turn [UL]
    + Booster Turn [UR]
   + Gravity Changers
   + Intersections
    + Instersection [LD]
    + Instersection [LU]
    + Instersection [RD]
    + Instersection [RU]
    + Instersection [T]
    + Alternator
    + Attachment [Booster]
    + Launcher
    + Line
    + Organizer
    + Splitter
    + Turn [Angle]
    + Turn [Smooth]
  + Starter [Enter]

1.1 Beta
 + Renamed to 1.X Beta
 + Eliminator [Square Group > Modules]
 = Changed Starter [Enter]
 o Fixed/Changed 1.0 Beta Change Log

1.1.1 Beta
 = Changed Installation Method to .msi

1.2 Beta
 + Bowl [Square Group > Navigation]
 + Catcher [Square Group > Navigation]
 + Marble Cutter [Square Group > Building Kit]
 = Changed Eliminator to use Boosters
 = Reverte Installation Method back to .zip
 - Removed Stats in README
 + New Directory [Square Group > Large Version]
  + Large Starter [Enter]
  + Navigation
   + Large Organizer